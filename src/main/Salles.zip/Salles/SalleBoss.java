package main.Salles;

import main.Salle;

public class SalleBoss extends Salle {

    @Override
    protected void tour() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'tour'");
    }

    @Override
    protected boolean isOver() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isOver'");
    }

}
